<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<?php ($yo = auth()->user()); ?>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex flex-wrap gap-2">
        <input type="text" name="buscar" value="<?php echo e($buscar); ?>" class="form-control" style="max-width:220px" placeholder="Nombre o email">
        <select name="rol" class="form-select" style="max-width:200px">
            <option value="">Todos los roles</option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($clave); ?>" <?php if($rol === $clave): echo 'selected'; endif; ?>><?php echo e($nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($yo->esSuperadmin()): ?>
            <select name="empresa_id" class="form-select" style="max-width:220px">
                <option value="">Todas las empresas</option>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>" <?php if((string) $empId === (string) $e->id): echo 'selected'; endif; ?>><?php echo e($e->razon_social); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php endif; ?>
        <button class="btn btn-outline-secondary"><i class="bi bi-funnel"></i></button>
        <?php if($buscar || $rol || $empId): ?>
            <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nuevo usuario
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <?php if($yo->esSuperadmin()): ?><th>Empresa</th><?php endif; ?>
                    <th>Rol</th>
                    <th class="d-none d-md-table-cell">Último acceso</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold">
                        <?php echo e($usuario->name); ?>

                        <?php if($usuario->id === $yo->id): ?><span class="badge text-bg-light ms-1">Vos</span><?php endif; ?>
                    </td>
                    <td><?php echo e($usuario->email); ?></td>
                    <?php if($yo->esSuperadmin()): ?>
                        <td><?php echo e($usuario->empresa?->razon_social ?? '—'); ?></td>
                    <?php endif; ?>
                    <td><span class="badge text-bg-primary bg-opacity-75"><?php echo e($usuario->rol_nombre); ?></span></td>
                    <td class="d-none d-md-table-cell small text-muted">
                        <?php echo e($usuario->ultimo_acceso?->format('d/m/Y H:i') ?? 'Nunca'); ?>

                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo e($usuario->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                            <?php echo e($usuario->activo ? 'Activo' : 'Inactivo'); ?>

                        </span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('usuarios.edit', $usuario)); ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <?php if($usuario->id !== $yo->id): ?>
                            <form method="POST" action="<?php echo e(route('usuarios.destroy', $usuario)); ?>" class="d-inline"
                                  onsubmit="return confirm('¿Eliminar el usuario <?php echo e(addslashes($usuario->name)); ?>?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay usuarios para mostrar.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($usuarios->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/usuarios/index.blade.php ENDPATH**/ ?>
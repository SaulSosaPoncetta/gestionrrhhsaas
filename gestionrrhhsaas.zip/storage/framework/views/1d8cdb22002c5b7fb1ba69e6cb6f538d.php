<?php $__env->startSection('title', 'Parte diario'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $Formato = \App\Support\Formato::class;
?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
<?php endif; ?>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex flex-wrap gap-2 align-items-center">
        <div class="input-group" style="width:auto">
            <a href="<?php echo e(route('asistencia.parte', ['fecha' => $fecha->copy()->subDay()->format('Y-m-d'), 'area_id' => $areaId])); ?>"
               class="btn btn-outline-secondary" title="Día anterior"><i class="bi bi-chevron-left"></i></a>
            <input type="date" name="fecha" value="<?php echo e($fecha->format('Y-m-d')); ?>" class="form-control" onchange="this.form.submit()">
            <a href="<?php echo e(route('asistencia.parte', ['fecha' => $fecha->copy()->addDay()->format('Y-m-d'), 'area_id' => $areaId])); ?>"
               class="btn btn-outline-secondary" title="Día siguiente"><i class="bi bi-chevron-right"></i></a>
        </div>
        <select name="area_id" class="form-select" style="max-width:220px" onchange="this.form.submit()">
            <option value="">Todas las áreas</option>
            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id); ?>" <?php if((string) $areaId === (string) $a->id): echo 'selected'; endif; ?>><?php echo e(str_repeat('— ', $a->nivel)); ?><?php echo e($a->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($estado): ?><input type="hidden" name="estado" value="<?php echo e($estado); ?>"><?php endif; ?>
        <?php if (! ($fecha->isToday())): ?>
            <a href="<?php echo e(route('asistencia.parte', ['area_id' => $areaId])); ?>" class="btn btn-outline-secondary">Hoy</a>
        <?php endif; ?>
    </form>
    <button class="btn btn-primary" onclick="abrirFichada({ fecha: <?php echo \Illuminate\Support\Js::from($fecha->format('Y-m-d'))->toHtml() ?> })">
        <i class="bi bi-plus-lg me-1"></i>Registrar fichada
    </button>
</div>

<h2 class="h6 text-muted mb-3">
    <?php echo e(ucfirst($fecha->locale('es')->isoFormat('dddd D [de] MMMM [de] YYYY'))); ?>

</h2>


<?php
    $tarjetas = [
        'presente'   => ['Presentes', 'success'],
        'trabajando' => ['En jornada', 'primary'],
        'tarde'      => ['Llegadas tarde', 'warning'],
        'ausente'    => ['Ausentes', 'danger'],
        'licencia'   => ['De licencia', 'info'],
        'incompleto' => ['Incompletas', 'info'],
        'pendiente'  => ['Pendientes', 'secondary'],
    ];
?>
<div class="row g-2 mb-3">
    <?php $__currentLoopData = $tarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => [$titulo, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-3 col-xl">
            <a href="<?php echo e(route('asistencia.parte', ['fecha' => $fecha->format('Y-m-d'), 'area_id' => $areaId, 'estado' => $estado === $clave ? null : $clave])); ?>"
               class="card border-0 shadow-sm text-decoration-none h-100 <?php echo e($estado === $clave ? 'border border-2 border-' . $color : ''); ?>">
                <div class="card-body py-2">
                    <div class="small text-muted"><?php echo e($titulo); ?></div>
                    <div class="fs-4 fw-semibold text-<?php echo e($color === 'secondary' ? 'dark' : $color); ?>"><?php echo e($conteo[$clave] ?? 0); ?></div>
                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if($estado): ?>
    <div class="mb-2 small">
        Mostrando: <span class="badge text-bg-dark"><?php echo e(\App\Services\Asistencia\DiaAsistencia::ESTADOS[$estado][0] ?? $estado); ?></span>
        <a href="<?php echo e(route('asistencia.parte', ['fecha' => $fecha->format('Y-m-d'), 'area_id' => $areaId])); ?>" class="ms-1">ver todos</a>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Empleado</th>
                    <th class="d-none d-md-table-cell">Horario</th>
                    <th class="text-center">Entrada</th>
                    <th class="text-center">Salida</th>
                    <th class="text-center d-none d-md-table-cell">Trabajado</th>
                    <th class="text-center d-none d-lg-table-cell">Tarde</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end"></th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $filas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as ['empleado' => $emp, 'dia' => $dia]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('asistencia.empleado', [$emp, 'mes' => $fecha->format('Y-m')])); ?>" class="fw-semibold text-decoration-none text-dark">
                            <?php echo e($emp->nombre_completo); ?>

                        </a>
                        <div class="small text-muted">Leg. <?php echo e($emp->legajo); ?><?php if($emp->area): ?> · <?php echo e($emp->area->nombre); ?><?php endif; ?></div>
                    </td>
                    <td class="d-none d-md-table-cell small"><?php echo e($dia->textoProgramado()); ?></td>
                    <td class="text-center font-monospace <?php echo e($dia->minutosTarde ? 'text-danger fw-semibold' : ''); ?>">
                        <?php echo e($dia->entradaReal?->format('H:i') ?? '—'); ?>

                    </td>
                    <td class="text-center font-monospace <?php echo e($dia->minutosSalidaAnticipada ? 'text-danger' : ''); ?>">
                        <?php echo e($dia->salidaReal?->format('H:i') ?? '—'); ?>

                    </td>
                    <td class="text-center d-none d-md-table-cell"><?php echo e($Formato::horas($dia->minutosTrabajados)); ?></td>
                    <td class="text-center d-none d-lg-table-cell"><?php echo e($dia->minutosTarde ? $dia->minutosTarde . ' min' : '—'); ?></td>
                    <td class="text-center">
                        <span class="badge text-bg-<?php echo e($dia->color()); ?>" title="<?php echo e($dia->feriado); ?>"><?php echo e($dia->etiqueta()); ?></span>
                        <?php if($dia->licencia): ?><div class="small text-muted"><?php echo e($dia->licencia); ?></div><?php endif; ?>
                    </td>
                    <td class="text-end">
                        <button class="btn btn-sm btn-outline-secondary" title="Registrar fichada"
                                onclick="abrirFichada({ empleado_id: <?php echo e($emp->id); ?>, fecha: <?php echo \Illuminate\Support\Js::from($fecha->format('Y-m-d'))->toHtml() ?>, tipo: <?php echo \Illuminate\Support\Js::from($dia->entradaReal && ! $dia->salidaReal ? 'salida' : 'entrada')->toHtml() ?> })">
                            <i class="bi bi-plus-lg"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">No hay empleados para mostrar.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo $__env->make('asistencia._modal_fichada', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/asistencia/parte.blade.php ENDPATH**/ ?>
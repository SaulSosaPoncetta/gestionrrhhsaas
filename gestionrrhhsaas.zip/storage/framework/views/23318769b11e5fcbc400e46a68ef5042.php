<?php $__env->startSection('title', 'Empresas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex gap-2">
        <input type="text" name="buscar" value="<?php echo e($buscar); ?>" class="form-control" placeholder="Razón social o CUIT">
        <button class="btn btn-outline-secondary"><i class="bi bi-search"></i></button>
        <?php if($buscar): ?>
            <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('empresas.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nueva empresa
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Empresa</th>
                    <th>CUIT</th>
                    <th class="d-none d-md-table-cell">Condición IVA</th>
                    <th class="text-center">Usuarios</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <?php if($empresa->logo): ?>
                                <img src="<?php echo e(asset('storage/'.$empresa->logo)); ?>" alt="" width="32" height="32" class="rounded object-fit-cover">
                            <?php else: ?>
                                <span class="d-inline-flex align-items-center justify-content-center rounded bg-light text-secondary" style="width:32px;height:32px">
                                    <i class="bi bi-building"></i>
                                </span>
                            <?php endif; ?>
                            <div>
                                <div class="fw-semibold"><?php echo e($empresa->razon_social); ?></div>
                                <?php if($empresa->nombre_fantasia): ?>
                                    <div class="small text-muted"><?php echo e($empresa->nombre_fantasia); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($empresa->cuit); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($empresa->condicion_iva ?? '—'); ?></td>
                    <td class="text-center"><?php echo e($empresa->usuarios_count); ?></td>
                    <td class="text-center">
                        <form method="POST" action="<?php echo e(route('empresas.toggle', $empresa)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button class="badge border-0 <?php echo e($empresa->activa ? 'text-bg-success' : 'text-bg-secondary'); ?>" title="Cambiar estado">
                                <?php echo e($empresa->activa ? 'Activa' : 'Inactiva'); ?>

                            </button>
                        </form>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('empresas.edit', $empresa)); ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('empresas.destroy', $empresa)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar la empresa <?php echo e(addslashes($empresa->razon_social)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">No hay empresas cargadas.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($empresas->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/empresas/index.blade.php ENDPATH**/ ?>
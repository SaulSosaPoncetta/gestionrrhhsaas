<?php $__env->startSection('title', 'Mis licencias'); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
<?php endif; ?>

<div class="row g-3 mb-3">
    <?php $__currentLoopData = $saldos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anio => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-lg-4">
            <div class="card border-0 shadow-sm h-100"><div class="card-body">
                <div class="small text-muted">Vacaciones <?php echo e($anio); ?></div>
                <div class="fs-3 fw-semibold <?php echo e($s['saldo'] < 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($s['saldo']); ?> <span class="fs-6 fw-normal text-muted">días</span></div>
                <div class="small text-muted">
                    Corresponden <?php echo e($s['corresponden'] + $s['ajuste']); ?> · tomados <?php echo e($s['tomados']); ?>

                    <?php if($s['pendientes']): ?> · <?php echo e($s['pendientes']); ?> pedidos <?php endif; ?>
                </div>
            </div></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6 col-lg-4 d-flex align-items-center">
        <a href="<?php echo e(route('portal.licencias.create')); ?>" class="btn btn-primary btn-lg w-100"><i class="bi bi-plus-lg me-1"></i>Pedir licencia</a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <ul class="list-group list-group-flush">
        <?php $__empty_1 = true; $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item">
                <div class="d-flex flex-wrap gap-2 justify-content-between align-items-start">
                    <div>
                        <span class="badge text-bg-<?php echo e($l->tipo->color); ?>"><?php echo e($l->tipo->nombre); ?></span>
                        <span class="badge text-bg-<?php echo e($l->estado_color); ?>"><?php echo e($l->estado_nombre); ?></span>
                        <div class="mt-1"><?php echo e($l->periodo_texto); ?> · <strong><?php echo e($l->dias); ?></strong> <?php echo e($l->tipo->esHabiles() ? 'días hábiles' : 'días'); ?></div>
                        <?php if($l->observaciones): ?><div class="small text-muted"><?php echo e($l->observaciones); ?></div><?php endif; ?>
                        <?php if($l->motivo_rechazo): ?><div class="small text-danger">Motivo: <?php echo e($l->motivo_rechazo); ?></div><?php endif; ?>
                        <?php if($l->resueltaPor && ! $l->esPendiente() && $l->estado !== 'cancelada'): ?>
                            <div class="small text-muted"><?php echo e($l->estado_nombre); ?> por <?php echo e($l->resueltaPor->name); ?> el <?php echo e($l->resuelta_at?->format('d/m/Y')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex flex-wrap gap-2 align-items-center">
                        <?php if($l->certificado): ?>
                            <a href="<?php echo e(route('portal.licencias.certificado.ver', $l)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-file-earmark-medical me-1"></i>Certificado
                            </a>
                        <?php elseif(in_array($l->estado, ['pendiente', 'aprobada']) && $l->tipo->requiere_certificado): ?>
                            <form method="POST" action="<?php echo e(route('portal.licencias.certificado', $l)); ?>" enctype="multipart/form-data" class="d-flex gap-1">
                                <?php echo csrf_field(); ?>
                                <input type="file" name="certificado" accept=".pdf,.jpg,.jpeg,.png,.webp" class="form-control form-control-sm" style="max-width:200px" required>
                                <button class="btn btn-sm btn-outline-warning" title="Adjuntar certificado"><i class="bi bi-upload"></i></button>
                            </form>
                        <?php endif; ?>
                        <?php if($l->esPendiente()): ?>
                            <form method="POST" action="<?php echo e(route('portal.licencias.cancelar', $l)); ?>" onsubmit="return confirm('¿Cancelar esta solicitud?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button class="btn btn-sm btn-outline-danger">Cancelar</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="list-group-item text-center text-muted py-5">No tenés licencias registradas.</li>
        <?php endif; ?>
    </ul>
</div>

<div class="mt-3"><?php echo e($licencias->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/licencias.blade.php ENDPATH**/ ?>
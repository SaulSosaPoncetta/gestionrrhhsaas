<?php $__env->startSection('title', 'Conceptos de liquidación'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <form method="POST" action="<?php echo e(route('conceptos.predeterminados')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-outline-primary"><i class="bi bi-magic me-1"></i>Cargar conceptos predeterminados</button>
    </form>
    <a href="<?php echo e(route('conceptos.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nuevo concepto</a>
</div>

<?php if($conceptos->isEmpty()): ?>
    <div class="card border-0 shadow-sm"><div class="card-body text-center text-muted py-5">
        No hay conceptos. Usá «Cargar conceptos predeterminados» para empezar con los habituales (básico, antigüedad, presentismo, horas extra, aportes...).
    </div></div>
<?php endif; ?>

<?php $__currentLoopData = \App\Models\Concepto::TIPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $titulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($conceptos->has($tipo)): ?>
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white fw-semibold"><?php echo e($titulo); ?>s</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:80px">Código</th>
                            <th>Concepto</th>
                            <th class="d-none d-md-table-cell">Cálculo</th>
                            <th class="text-center d-none d-lg-table-cell">Orden</th>
                            <th class="text-center">Aplicación</th>
                            <th class="text-center">Estado</th>
                            <th class="text-end"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $conceptos[$tipo]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($c->activo ? '' : 'text-muted'); ?>">
                            <td class="font-monospace"><?php echo e($c->codigo); ?></td>
                            <td>
                                <span class="fw-semibold"><?php echo e($c->nombre); ?></span>
                                <?php if($c->convenio): ?><div class="small text-muted">Solo <?php echo e($c->convenio->nombre); ?></div><?php endif; ?>
                                <?php if($c->parametro('solo_con_convenio')): ?><div class="small text-muted">Solo empleados en convenio</div><?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell small">
                                <?php echo e($c->descripcion_calculo); ?>

                                <?php if($c->forma === 'presentismo'): ?>
                                    <div class="text-muted">Se pierde con más de <?php echo e($c->parametro('max_ausencias', 0)); ?> ausencias o <?php echo e($c->parametro('max_tardanzas', 2)); ?> llegadas tarde</div>
                                <?php endif; ?>
                            </td>
                            <td class="text-center d-none d-lg-table-cell"><?php echo e($c->orden); ?></td>
                            <td class="text-center">
                                <?php if($c->forma === 'sac'): ?>
                                    <span class="badge text-bg-info">En el SAC</span>
                                <?php elseif($c->automatico): ?>
                                    <span class="badge text-bg-primary">Automático</span>
                                <?php else: ?>
                                    <span class="badge text-bg-light">Por novedad</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?php echo e($c->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>"><?php echo e($c->activo ? 'Activo' : 'Inactivo'); ?></span>
                            </td>
                            <td class="text-end text-nowrap">
                                <a href="<?php echo e(route('conceptos.edit', $c)); ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="bi bi-pencil"></i></a>
                                <form method="POST" action="<?php echo e(route('conceptos.destroy', $c)); ?>" class="d-inline"
                                      onsubmit="return confirm('¿Eliminar el concepto <?php echo e(addslashes($c->nombre)); ?>?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="small text-muted">
    <p class="mb-1">Se calculan en orden: primero los remunerativos, después los no remunerativos y al final los descuentos (por el número de orden dentro de cada grupo).
    La base «total remunerativo» es lo acumulado hasta ese concepto; en los descuentos es el total final.</p>
    <p class="mb-0"><strong>Importante:</strong> los porcentajes de convenio (antigüedad, presentismo, sindicato, divisor de horas) vienen con los de Comercio.
    Ajustalos según el CCT y cargá en los aportes el tope de base imponible vigente (ANSES lo actualiza periódicamente).</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/conceptos/index.blade.php ENDPATH**/ ?>
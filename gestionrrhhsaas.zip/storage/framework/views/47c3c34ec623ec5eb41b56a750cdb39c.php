<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Inicio'); ?> · <?php echo e(config('app.name', 'Gestión RRHH')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/tema.css')); ?>?v=1" rel="stylesheet">
    <style>
        .barra-principal .navbar-brand { font-weight: 600; line-height: 1.1; }
        .barra-principal .navbar-brand small { display: block; font-size: .7rem; font-weight: 400; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .barra-principal .nav-link { border-radius: .375rem; padding: .45rem .75rem !important; }
        .barra-principal .dropdown-menu { border: 0; box-shadow: 0 .5rem 1rem rgba(0,0,0,.15); margin-top: .35rem; }
        .barra-principal .dropdown-item.active, .barra-principal .dropdown-item:active { font-weight: 600; }
        .barra-principal .dropdown-item i { width: 1.25rem; display: inline-block; }
        .barra-principal .dropdown-header { font-size: .7rem; text-transform: uppercase; letter-spacing: .03em; }
        .barra-principal .badge-menu { font-size: .65rem; vertical-align: top; }
        @media (max-width: 1199.98px) {
            .barra-principal .navbar-collapse { padding: .5rem 0 1rem; max-height: calc(100vh - 60px); overflow-y: auto; }
            .barra-principal .dropdown-menu { box-shadow: none; margin-top: 0; }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<?php ($u = auth()->user()); ?>
<?php ($miLegajo = ($u->esUsuarioPortal() || $u->esAdmin()) ? $u->empleado : null); ?>
<?php ($pendientesLic = $u->esAdmin() ? \App\Models\Licencia::where('estado', 'pendiente')->count() : 0); ?>
<?php ($pendEquipo = ($u->esSupervisor() && $miLegajo) ? \App\Models\Licencia::where('estado', 'pendiente')->whereIn('empleado_id', \App\Models\Empleado::activos()->where('supervisor_id', $miLegajo->id)->pluck('id'))->count() : 0); ?>
<?php ($activo = fn (...$rutas) => request()->routeIs(...$rutas) ? 'active' : ''); ?>

<nav class="navbar navbar-expand-xl navbar-dark barra-principal sticky-top shadow-sm">
    <div class="container-fluid px-3">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo e(route($u->esUsuarioPortal() ? 'portal.inicio' : 'dashboard')); ?>">
            <i class="bi bi-people-fill fs-4"></i>
            <span>
                <?php echo e(config('app.name', 'Gestión RRHH')); ?>

                <?php if($u->empresa): ?><small><?php echo e($u->empresa->nombre); ?></small><?php endif; ?>
            </span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal" aria-label="Menú">
            <span class="navbar-toggler-icon"></span>
            <?php if($pendientesLic || $pendEquipo): ?><span class="badge rounded-pill text-bg-warning badge-menu"><?php echo e($pendientesLic + $pendEquipo); ?></span><?php endif; ?>
        </button>

        <div class="collapse navbar-collapse" id="menuPrincipal">
            <ul class="navbar-nav me-auto gap-xl-1">

                
                <?php if($u->esUsuarioPortal()): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('portal.inicio')); ?>" href="<?php echo e(route('portal.inicio')); ?>"><i class="bi bi-house me-1"></i>Inicio</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('dashboard')); ?>" href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-speedometer2 me-1"></i>Inicio</a></li>
                <?php endif; ?>

                
                <?php if($u->esUsuarioPortal() && $miLegajo): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('portal.recibos*')); ?>" href="<?php echo e(route('portal.recibos')); ?>"><i class="bi bi-receipt me-1"></i>Mis recibos</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('portal.licencias*')); ?>" href="<?php echo e(route('portal.licencias')); ?>"><i class="bi bi-calendar-heart me-1"></i>Mis licencias</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('portal.asistencia')); ?>" href="<?php echo e(route('portal.asistencia')); ?>"><i class="bi bi-calendar-check me-1"></i>Mi asistencia</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('portal.datos*')); ?>" href="<?php echo e(route('portal.datos')); ?>"><i class="bi bi-person-lines-fill me-1"></i>Mis datos</a></li>
                    <?php if($u->esSupervisor()): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($activo('portal.equipo*')); ?>" href="<?php echo e(route('portal.equipo')); ?>">
                                <i class="bi bi-people me-1"></i>Mi equipo
                                <?php if($pendEquipo): ?><span class="badge rounded-pill text-bg-warning badge-menu"><?php echo e($pendEquipo); ?></span><?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                
                <?php if($u->esAdmin()): ?>
                    <li class="nav-item"><a class="nav-link <?php echo e($activo('empleados.*')); ?>" href="<?php echo e(route('empleados.index')); ?>"><i class="bi bi-person-vcard me-1"></i>Legajos</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('asistencia.*', 'fichadas.*', 'horarios.*', 'feriados.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-clipboard-check me-1"></i>Asistencia
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e($activo('asistencia.parte')); ?>" href="<?php echo e(route('asistencia.parte')); ?>"><i class="bi bi-clipboard-check"></i>Parte diario</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('fichadas.*')); ?>" href="<?php echo e(route('fichadas.index')); ?>"><i class="bi bi-fingerprint"></i>Fichadas</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('asistencia.resumen*', 'asistencia.empleado')); ?>" href="<?php echo e(route('asistencia.resumen')); ?>"><i class="bi bi-calendar3"></i>Resumen mensual</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><h6 class="dropdown-header">Configuración</h6></li>
                            <li><a class="dropdown-item <?php echo e($activo('horarios.*')); ?>" href="<?php echo e(route('horarios.index')); ?>"><i class="bi bi-clock"></i>Horarios</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('feriados.*')); ?>" href="<?php echo e(route('feriados.index')); ?>"><i class="bi bi-calendar-x"></i>Feriados</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('licencias.*', 'vacaciones.*', 'tipos-licencia.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-calendar-heart me-1"></i>Licencias
                            <?php if($pendientesLic): ?><span class="badge rounded-pill text-bg-warning badge-menu"><?php echo e($pendientesLic); ?></span><?php endif; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item d-flex align-items-center gap-2 <?php echo e($activo('licencias.index', 'licencias.create', 'licencias.edit')); ?>" href="<?php echo e(route('licencias.index')); ?>">
                                    <i class="bi bi-calendar-heart"></i>Licencias
                                    <?php if($pendientesLic): ?><span class="badge rounded-pill text-bg-warning ms-auto"><?php echo e($pendientesLic); ?> pend.</span><?php endif; ?>
                                </a>
                            </li>
                            <li><a class="dropdown-item <?php echo e($activo('vacaciones.*')); ?>" href="<?php echo e(route('vacaciones.index')); ?>"><i class="bi bi-sun"></i>Vacaciones</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('licencias.calendario')); ?>" href="<?php echo e(route('licencias.calendario')); ?>"><i class="bi bi-calendar-week"></i>Calendario</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><h6 class="dropdown-header">Configuración</h6></li>
                            <li><a class="dropdown-item <?php echo e($activo('tipos-licencia.*')); ?>" href="<?php echo e(route('tipos-licencia.index')); ?>"><i class="bi bi-tags"></i>Tipos de licencia</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('liquidaciones.*', 'conceptos.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-cash-stack me-1"></i>Sueldos
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e($activo('liquidaciones.*')); ?>" href="<?php echo e(route('liquidaciones.index')); ?>"><i class="bi bi-cash-stack"></i>Liquidaciones</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><h6 class="dropdown-header">Configuración</h6></li>
                            <li><a class="dropdown-item <?php echo e($activo('conceptos.*')); ?>" href="<?php echo e(route('conceptos.index')); ?>"><i class="bi bi-list-columns-reverse"></i>Conceptos</a></li>
                        </ul>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('areas.*', 'puestos.*', 'convenios.*', 'categorias.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-diagram-3 me-1"></i>Estructura
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e($activo('areas.*')); ?>" href="<?php echo e(route('areas.index')); ?>"><i class="bi bi-diagram-3"></i>Áreas</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('puestos.*')); ?>" href="<?php echo e(route('puestos.index')); ?>"><i class="bi bi-briefcase"></i>Puestos</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('convenios.*', 'categorias.*')); ?>" href="<?php echo e(route('convenios.index')); ?>"><i class="bi bi-journal-text"></i>Convenios y categorías</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <?php if($u->esSuperadmin() || $u->esAdmin()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('empresas.*', 'usuarios.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-gear me-1"></i>Administración
                        </a>
                        <ul class="dropdown-menu">
                            <?php if($u->esSuperadmin()): ?>
                                <li><a class="dropdown-item <?php echo e($activo('empresas.*')); ?>" href="<?php echo e(route('empresas.index')); ?>"><i class="bi bi-building"></i>Empresas</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item <?php echo e($activo('usuarios.*')); ?>" href="<?php echo e(route('usuarios.index')); ?>"><i class="bi bi-person-gear"></i>Usuarios</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                
                <?php if(! $u->esUsuarioPortal() && $miLegajo): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e($activo('portal.*')); ?>" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-badge me-1"></i>Mi portal
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e($activo('portal.inicio')); ?>" href="<?php echo e(route('portal.inicio')); ?>"><i class="bi bi-person-badge"></i>Mi inicio</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('portal.recibos*')); ?>" href="<?php echo e(route('portal.recibos')); ?>"><i class="bi bi-receipt"></i>Mis recibos</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('portal.licencias*')); ?>" href="<?php echo e(route('portal.licencias')); ?>"><i class="bi bi-calendar-heart"></i>Mis licencias</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('portal.asistencia')); ?>" href="<?php echo e(route('portal.asistencia')); ?>"><i class="bi bi-calendar-check"></i>Mi asistencia</a></li>
                            <li><a class="dropdown-item <?php echo e($activo('portal.datos*')); ?>" href="<?php echo e(route('portal.datos')); ?>"><i class="bi bi-person-lines-fill"></i>Mis datos</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>

            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i><?php echo e($u->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text small text-muted"><?php echo e($u->rol_nombre); ?></span></li>
                        <li><a class="dropdown-item <?php echo e($activo('password.*')); ?>" href="<?php echo e(route('password.editar')); ?>"><i class="bi bi-key"></i>Cambiar contraseña</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item"><i class="bi bi-box-arrow-right"></i>Cerrar sesión</button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="container-fluid p-3 p-md-4">
    <h1 class="h5 fw-semibold mb-3"><?php echo $__env->yieldContent('title', 'Inicio'); ?></h1>

    <?php if(session('ok')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('ok')); ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if(session('aviso')): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle me-1"></i><?php echo e(session('aviso')); ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo e(session('error')); ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/layouts/app.blade.php ENDPATH**/ ?>
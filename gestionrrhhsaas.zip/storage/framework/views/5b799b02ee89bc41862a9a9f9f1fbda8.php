<?php $__env->startSection('title', 'Puestos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex flex-wrap gap-2">
        <input type="text" name="buscar" value="<?php echo e($buscar); ?>" class="form-control" style="max-width:220px" placeholder="Nombre del puesto">
        <select name="area_id" class="form-select" style="max-width:240px">
            <option value="">Todas las áreas</option>
            <option value="sin" <?php if($areaId === 'sin'): echo 'selected'; endif; ?>>Sin área asignada</option>
            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id); ?>" <?php if((string) $areaId === (string) $a->id): echo 'selected'; endif; ?>>
                    <?php echo e(str_repeat('— ', $a->nivel)); ?><?php echo e($a->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-outline-secondary"><i class="bi bi-funnel"></i></button>
        <?php if($buscar || $areaId): ?>
            <a href="<?php echo e(route('puestos.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('puestos.create', ['area' => is_numeric($areaId) ? $areaId : null])); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nuevo puesto
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Puesto</th>
                    <th>Área</th>
                    <th class="d-none d-lg-table-cell">Descripción</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $puestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($puesto->nombre); ?></td>
                    <td><?php echo e($puesto->area?->nombre ?? '—'); ?></td>
                    <td class="d-none d-lg-table-cell small text-muted"><?php echo e(\Illuminate\Support\Str::limit($puesto->descripcion, 80)); ?></td>
                    <td class="text-center">
                        <span class="badge <?php echo e($puesto->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                            <?php echo e($puesto->activo ? 'Activo' : 'Inactivo'); ?>

                        </span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('puestos.edit', $puesto)); ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('puestos.destroy', $puesto)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar el puesto <?php echo e(addslashes($puesto->nombre)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">No hay puestos para mostrar.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($puestos->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/puestos/index.blade.php ENDPATH**/ ?>
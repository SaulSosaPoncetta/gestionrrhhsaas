<?php $__env->startSection('title', 'Mis recibos'); ?>

<?php $__env->startSection('content'); ?>
<p class="text-muted small">Acá aparecen los recibos de las liquidaciones ya cerradas. Podés verlos, imprimirlos o guardarlos en PDF, y dejar constancia de que los recibiste.</p>

<div class="card border-0 shadow-sm">
    <ul class="list-group list-group-flush">
        <?php $__empty_1 = true; $__currentLoopData = $recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="list-group-item">
                <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center">
                    <div>
                        <div class="fw-semibold"><?php echo e($r->liquidacion->periodo_texto); ?></div>
                        <div class="small text-muted">
                            <?php if($r->liquidacion->fecha_pago): ?> Pagado el <?php echo e($r->liquidacion->fecha_pago->format('d/m/Y')); ?> · <?php endif; ?>
                            Neto <strong>$ <?php echo e(number_format($r->neto, 2, ',', '.')); ?></strong>
                        </div>
                    </div>
                    <div class="d-flex gap-2 align-items-center">
                        <?php if($r->conformado_at): ?>
                            <span class="small text-success"><i class="bi bi-check2-circle"></i> Conforme el <?php echo e($r->conformado_at->format('d/m/Y')); ?></span>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('portal.recibos.conformar', $r)); ?>"
                                  onsubmit="return confirm('¿Confirmás que recibiste el recibo de <?php echo e($r->liquidacion->periodo_texto); ?> y estás conforme?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button class="btn btn-sm btn-outline-success"><i class="bi bi-check2 me-1"></i>Dar conformidad</button>
                            </form>
                        <?php endif; ?>
                        <a href="<?php echo e(route('portal.recibos.ver', $r)); ?>" target="_blank" class="btn btn-sm btn-primary"><i class="bi bi-eye me-1"></i>Ver</a>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="list-group-item text-center text-muted py-5">Todavía no hay recibos disponibles.</li>
        <?php endif; ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/recibos.blade.php ENDPATH**/ ?>
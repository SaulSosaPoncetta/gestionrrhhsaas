<?php $__env->startSection('title', 'Licencias'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-end mb-3">
    <form method="GET" class="d-flex flex-wrap gap-2 align-items-end">
        <div>
            <label class="form-label small mb-1">Estado</label>
            <select name="estado" class="form-select">
                <option value="">Todos</option>
                <?php $__currentLoopData = \App\Models\Licencia::ESTADOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => [$nombre]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k); ?>" <?php if($estado === $k): echo 'selected'; endif; ?>><?php echo e($nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="form-label small mb-1">Tipo</label>
            <select name="tipo_id" class="form-select" style="max-width:220px">
                <option value="">Todos</option>
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t->id); ?>" <?php if((string) $tipoId === (string) $t->id): echo 'selected'; endif; ?>><?php echo e($t->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="form-label small mb-1">Empleado</label>
            <select name="empleado_id" class="form-select" style="max-width:220px">
                <option value="">Todos</option>
                <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($emp->id); ?>" <?php if((string) $empleadoId === (string) $emp->id): echo 'selected'; endif; ?>><?php echo e($emp->nombre_completo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="form-label small mb-1">Año</label>
            <input type="number" name="anio" value="<?php echo e($anio); ?>" class="form-control" style="width:100px" min="2000" max="2100" placeholder="Todos">
        </div>
        <button class="btn btn-outline-secondary"><i class="bi bi-funnel"></i></button>
        <?php if($estado || $tipoId || $empleadoId || $anio): ?>
            <a href="<?php echo e(route('licencias.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <div class="d-flex gap-2">
        <?php if($pendientes && $estado !== 'pendiente'): ?>
            <a href="<?php echo e(route('licencias.index', ['estado' => 'pendiente'])); ?>" class="btn btn-warning">
                <i class="bi bi-hourglass-split me-1"></i><?php echo e($pendientes); ?> pendiente<?php echo e($pendientes === 1 ? '' : 's'); ?>

            </a>
        <?php endif; ?>
        <a href="<?php echo e(route('licencias.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nueva licencia</a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Empleado</th>
                    <th>Tipo</th>
                    <th>Período</th>
                    <th class="text-center">Días</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="<?php echo e($l->esPendiente() ? 'table-warning' : ''); ?>">
                    <td>
                        <?php if($l->empleado): ?>
                            <a href="<?php echo e(route('empleados.show', $l->empleado)); ?>#licencias" class="fw-semibold text-decoration-none text-dark"><?php echo e($l->empleado->nombre_completo); ?></a>
                            <div class="small text-muted">Leg. <?php echo e($l->empleado->legajo); ?></div>
                        <?php else: ?>
                            <span class="text-muted">Empleado eliminado</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge text-bg-<?php echo e($l->tipo->color); ?>"><?php echo e($l->tipo->nombre); ?></span>
                        <?php if($l->periodo): ?><div class="small text-muted">Período <?php echo e($l->periodo); ?></div><?php endif; ?>
                        <?php if($l->observaciones): ?><div class="small text-muted text-truncate" style="max-width:240px" title="<?php echo e($l->observaciones); ?>"><?php echo e($l->observaciones); ?></div><?php endif; ?>
                    </td>
                    <td class="text-nowrap"><?php echo e($l->periodo_texto); ?></td>
                    <td class="text-center">
                        <?php echo e($l->dias); ?>

                        <div class="small text-muted"><?php echo e($l->tipo->esHabiles() ? 'hábiles' : 'corridos'); ?></div>
                    </td>
                    <td class="text-center">
                        <span class="badge text-bg-<?php echo e($l->estado_color); ?>"><?php echo e($l->estado_nombre); ?></span>
                        <?php if($l->resueltaPor && ! $l->esPendiente()): ?>
                            <div class="small text-muted" title="<?php echo e($l->resuelta_at?->format('d/m/Y H:i')); ?>"><?php echo e($l->resueltaPor->name); ?></div>
                        <?php endif; ?>
                        <?php if($l->motivo_rechazo): ?><div class="small text-danger"><?php echo e($l->motivo_rechazo); ?></div><?php endif; ?>
                    </td>
                    <td class="text-end text-nowrap">
                        <?php if($l->certificado): ?>
                            <a href="<?php echo e(route('licencias.certificado', $l)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="Ver certificado">
                                <i class="bi bi-file-earmark-medical"></i>
                            </a>
                        <?php elseif($l->faltaCertificado()): ?>
                            <span class="btn btn-sm btn-outline-warning disabled" title="Falta el certificado"><i class="bi bi-exclamation-triangle"></i></span>
                        <?php endif; ?>

                        <?php if($l->esPendiente()): ?>
                            <form method="POST" action="<?php echo e(route('licencias.aprobar', $l)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button class="btn btn-sm btn-success" title="Aprobar"><i class="bi bi-check-lg"></i></button>
                            </form>
                            <form method="POST" action="<?php echo e(route('licencias.rechazar', $l)); ?>" class="d-inline"
                                  onsubmit="const m = prompt('Motivo del rechazo (opcional):'); if (m === null) return false; this.motivo_rechazo.value = m;">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="motivo_rechazo">
                                <button class="btn btn-sm btn-outline-danger" title="Rechazar"><i class="bi bi-x-lg"></i></button>
                            </form>
                        <?php elseif($l->esAprobada()): ?>
                            <form method="POST" action="<?php echo e(route('licencias.cancelar', $l)); ?>" class="d-inline"
                                  onsubmit="return confirm('¿Cancelar esta licencia? Los días vuelven al saldo y las ausencias dejan de estar justificadas.')">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button class="btn btn-sm btn-outline-secondary" title="Cancelar"><i class="bi bi-slash-circle"></i></button>
                            </form>
                        <?php endif; ?>

                        <a href="<?php echo e(route('licencias.edit', $l)); ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="<?php echo e(route('licencias.destroy', $l)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar esta licencia? Si fue cargada por error está bien; si no, conviene cancelarla.')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">No hay licencias para mostrar.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($licencias->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/licencias/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Áreas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex gap-2">
        <input type="text" name="buscar" value="<?php echo e($buscar); ?>" class="form-control" placeholder="Nombre o código">
        <button class="btn btn-outline-secondary"><i class="bi bi-search"></i></button>
        <?php if($buscar): ?>
            <a href="<?php echo e(route('areas.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('areas.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nueva área
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Área</th>
                    <th class="d-none d-md-table-cell">Código</th>
                    <?php if($buscar): ?><th class="d-none d-md-table-cell">Depende de</th><?php endif; ?>
                    <th class="text-center">Puestos</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <span style="padding-left: <?php echo e($area->nivel * 1.5); ?>rem">
                            <?php if($area->nivel > 0): ?><i class="bi bi-arrow-return-right text-muted me-1"></i><?php endif; ?>
                            <i class="bi bi-diagram-3 text-primary me-1"></i>
                            <span class="fw-semibold"><?php echo e($area->nombre); ?></span>
                        </span>
                    </td>
                    <td class="d-none d-md-table-cell"><?php echo e($area->codigo ?? '—'); ?></td>
                    <?php if($buscar): ?>
                        <td class="d-none d-md-table-cell"><?php echo e($area->padre?->nombre ?? '—'); ?></td>
                    <?php endif; ?>
                    <td class="text-center">
                        <a href="<?php echo e(route('puestos.index', ['area_id' => $area->id])); ?>" class="text-decoration-none">
                            <?php echo e($area->puestos_count); ?>

                        </a>
                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo e($area->activa ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                            <?php echo e($area->activa ? 'Activa' : 'Inactiva'); ?>

                        </span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('areas.create', ['padre' => $area->id])); ?>" class="btn btn-sm btn-outline-secondary" title="Agregar sub-área">
                            <i class="bi bi-node-plus"></i>
                        </a>
                        <a href="<?php echo e(route('areas.edit', $area)); ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('areas.destroy', $area)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar el área <?php echo e(addslashes($area->nombre)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">No hay áreas cargadas.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/areas/index.blade.php ENDPATH**/ ?>
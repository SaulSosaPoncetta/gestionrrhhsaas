<?php $__env->startSection('title', 'Pedir licencia'); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('portal.licencias')); ?>" class="text-decoration-none small"><i class="bi bi-arrow-left"></i> Mis licencias</a>

<form method="POST" action="<?php echo e(route('portal.licencias.store')); ?>" enctype="multipart/form-data" class="mt-2">
    <?php echo csrf_field(); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body row g-3">
                    <div class="col-12">
                        <label class="form-label">Tipo de licencia *</label>
                        <select name="tipo_licencia_id" id="tipo_id" class="form-select <?php $__errorArgs = ['tipo_licencia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">— Elegí —</option>
                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>" data-vacaciones="<?php echo e($t->es_vacaciones ? 1 : 0); ?>" data-certificado="<?php echo e($t->requiere_certificado ? 1 : 0); ?>"
                                        data-descripcion="<?php echo e($t->descripcion); ?>"
                                        <?php if((string) old('tipo_licencia_id', $tipoId) === (string) $t->id): echo 'selected'; endif; ?>><?php echo e($t->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text" id="tipo-descripcion"></div>
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="form-label">Desde *</label>
                        <input type="date" name="fecha_desde" id="fecha_desde" value="<?php echo e(old('fecha_desde', today()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['fecha_desde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    </div>
                    <div class="col-6 col-md-4">
                        <label class="form-label">Hasta (inclusive) *</label>
                        <input type="date" name="fecha_hasta" id="fecha_hasta" value="<?php echo e(old('fecha_hasta', today()->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['fecha_hasta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    </div>
                    <div class="col-md-4" id="bloque-periodo">
                        <label class="form-label">Vacaciones del año</label>
                        <input type="number" name="periodo" id="periodo" value="<?php echo e(old('periodo', $periodo)); ?>" class="form-control" min="2000" max="2100">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Comentario para RRHH</label>
                        <textarea name="observaciones" rows="2" class="form-control" maxlength="2000"><?php echo e(old('observaciones')); ?></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Certificado <span class="text-muted small">(PDF o foto, máx. 5 MB)</span></label>
                        <input type="file" name="certificado" accept=".pdf,.jpg,.jpeg,.png,.webp" class="form-control <?php $__errorArgs = ['certificado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <div class="form-text text-warning d-none" id="aviso-certificado">Este tipo de licencia requiere certificado (lo podés adjuntar después).</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="text-muted small" id="calculo-vacio">Elegí el tipo y las fechas.</div>
                    <div class="d-none" id="calculo-datos">
                        <div class="display-6 fw-semibold" id="calculo-dias"></div>
                        <div class="text-muted small mb-2" id="calculo-unidad"></div>
                        <div id="calculo-maximo" class="small"></div>
                        <div id="calculo-saldo" class="small"></div>
                        <ul id="calculo-avisos" class="small text-warning ps-3 mt-2 mb-0"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex gap-2 mt-3">
        <button class="btn btn-primary"><i class="bi bi-send me-1"></i>Enviar solicitud</button>
        <a href="<?php echo e(route('portal.licencias')); ?>" class="btn btn-outline-secondary">Cancelar</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const url = <?php echo json_encode(route('portal.licencias.calcular-dias'), 15, 512) ?>;
    const $ = id => document.getElementById(id);
    const tipo = $('tipo_id'), desde = $('fecha_desde'), hasta = $('fecha_hasta'), periodo = $('periodo');

    function actualizarTipo() {
        const t = tipo.selectedOptions[0];
        $('bloque-periodo').classList.toggle('d-none', t?.dataset.vacaciones !== '1');
        $('aviso-certificado').classList.toggle('d-none', t?.dataset.certificado !== '1');
        $('tipo-descripcion').textContent = t?.dataset.descripcion ?? '';
    }

    let tmr;
    function calcular() {
        clearTimeout(tmr);
        tmr = setTimeout(async () => {
            if (!tipo.value || !desde.value || !hasta.value) return;
            if (hasta.value < desde.value) hasta.value = desde.value;
            const p = new URLSearchParams({ tipo_id: tipo.value, desde: desde.value, hasta: hasta.value, periodo: periodo.value || '' });
            try {
                const r = await fetch(url + '?' + p, { headers: { Accept: 'application/json' } });
                if (!r.ok) return;
                const d = await r.json();
                $('calculo-vacio').classList.add('d-none');
                $('calculo-datos').classList.remove('d-none');
                $('calculo-dias').textContent = d.dias + (d.dias === 1 ? ' día' : ' días');
                $('calculo-unidad').textContent = d.unidad;
                $('calculo-maximo').innerHTML = d.maximo ? `<span class="${d.dias > d.maximo ? 'text-danger fw-semibold' : 'text-muted'}">Máximo: ${d.maximo} días</span>` : '';
                $('calculo-saldo').innerHTML = d.disponible !== undefined
                    ? `Te quedan <strong>${d.disponible}</strong> días · después: <span class="${d.disponible - d.dias < 0 ? 'text-danger fw-semibold' : 'text-success'}">${d.disponible - d.dias}</span>` : '';
                $('calculo-avisos').innerHTML = (d.avisos || []).map(a => `<li>${a}</li>`).join('');
            } catch (e) {}
        }, 250);
    }

    tipo.addEventListener('change', () => { actualizarTipo(); calcular(); });
    [desde, hasta, periodo].forEach(el => el.addEventListener('change', calcular));
    actualizarTipo();
    calcular();
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/licencia_form.blade.php ENDPATH**/ ?>
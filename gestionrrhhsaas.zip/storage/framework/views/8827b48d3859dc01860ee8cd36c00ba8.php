<?php $__env->startSection('title', $licencia->exists ? 'Editar licencia' : 'Nueva licencia'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $l = $licencia;
?>

<form method="POST" enctype="multipart/form-data" action="<?php echo e($l->exists ? route('licencias.update', $l) : route('licencias.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($l->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        </div>
    <?php endif; ?>

    <?php if($l->exists): ?>
        <div class="alert alert-light border small">
            Estado actual: <span class="badge text-bg-<?php echo e($l->estado_color); ?>"><?php echo e($l->estado_nombre); ?></span>
            · Para aprobar, rechazar o cancelar usá los botones del listado.
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-body row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Empleado *</label>
                        <select name="empleado_id" id="empleado_id" class="form-select <?php $__errorArgs = ['empleado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">— Seleccionar —</option>
                            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($emp->id); ?>" <?php if((string) old('empleado_id', $l->empleado_id) === (string) $emp->id): echo 'selected'; endif; ?>>
                                    <?php echo e($emp->nombre_completo); ?> (leg. <?php echo e($emp->legajo); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Tipo de licencia *</label>
                        <select name="tipo_licencia_id" id="tipo_id" class="form-select <?php $__errorArgs = ['tipo_licencia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">— Seleccionar —</option>
                            <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>"
                                        data-vacaciones="<?php echo e($t->es_vacaciones ? 1 : 0); ?>"
                                        data-certificado="<?php echo e($t->requiere_certificado ? 1 : 0); ?>"
                                        data-descripcion="<?php echo e($t->descripcion); ?>"
                                        <?php if((string) old('tipo_licencia_id', $l->tipo_licencia_id) === (string) $t->id): echo 'selected'; endif; ?>><?php echo e($t->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text" id="tipo-descripcion"></div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Desde *</label>
                        <input type="date" name="fecha_desde" id="fecha_desde" value="<?php echo e(old('fecha_desde', $l->fecha_desde?->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['fecha_desde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Hasta (inclusive) *</label>
                        <input type="date" name="fecha_hasta" id="fecha_hasta" value="<?php echo e(old('fecha_hasta', $l->fecha_hasta?->format('Y-m-d'))); ?>"
                               class="form-control <?php $__errorArgs = ['fecha_hasta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    </div>
                    <div class="col-md-4" id="bloque-periodo">
                        <label class="form-label">Vacaciones del año *</label>
                        <input type="number" name="periodo" id="periodo" value="<?php echo e(old('periodo', $l->periodo)); ?>"
                               class="form-control <?php $__errorArgs = ['periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="2000" max="2100">
                    </div>

                    <div class="col-12">
                        <label class="form-label">Observaciones</label>
                        <textarea name="observaciones" rows="2" class="form-control"><?php echo e(old('observaciones', $l->observaciones)); ?></textarea>
                    </div>

                    <div class="col-md-8">
                        <label class="form-label">Certificado <span class="text-muted small">(PDF o imagen, máx. 5 MB)</span></label>
                        <input type="file" name="certificado" accept=".pdf,.jpg,.jpeg,.png,.webp" class="form-control <?php $__errorArgs = ['certificado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php if($l->certificado): ?>
                            <div class="small mt-1">
                                Actual: <a href="<?php echo e(route('licencias.certificado', $l)); ?>" target="_blank"><?php echo e($l->certificado_nombre); ?></a>
                                <span class="text-muted">· si subís otro se reemplaza</span>
                            </div>
                        <?php endif; ?>
                        <div class="form-text text-warning d-none" id="aviso-certificado">
                            <i class="bi bi-exclamation-triangle"></i> Este tipo de licencia requiere certificado.
                        </div>
                    </div>

                    <?php if (! ($l->exists)): ?>
                        <div class="col-md-4 d-flex align-items-end">
                            <div class="form-check form-switch">
                                <input type="checkbox" name="aprobar" value="1" id="aprobar" class="form-check-input" <?php if(old('aprobar', true)): echo 'checked'; endif; ?>>
                                <label for="aprobar" class="form-check-label">Aprobar al guardar</label>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm" id="panel-calculo">
                <div class="card-header bg-white fw-semibold"><i class="bi bi-calculator me-1"></i>Cálculo</div>
                <div class="card-body">
                    <div class="text-muted small" id="calculo-vacio">Elegí empleado, tipo y fechas.</div>
                    <div class="d-none" id="calculo-datos">
                        <div class="display-6 fw-semibold" id="calculo-dias">—</div>
                        <div class="text-muted small mb-2" id="calculo-unidad"></div>
                        <div id="calculo-maximo" class="small"></div>
                        <div id="calculo-saldo" class="small"></div>
                        <ul id="calculo-avisos" class="small text-warning ps-3 mt-2 mb-0"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex gap-2 mt-3">
        <button class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Guardar</button>
        <a href="<?php echo e(route('licencias.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const urlCalculo = <?php echo json_encode(route('licencias.calcular-dias'), 15, 512) ?>;
    const excluir = <?php echo json_encode($l->id, 15, 512) ?>;
    const $ = id => document.getElementById(id);

    const empleado = $('empleado_id'), tipo = $('tipo_id'), desde = $('fecha_desde'), hasta = $('fecha_hasta'), periodo = $('periodo');

    function tipoActual() {
        return tipo.selectedOptions[0] ?? null;
    }

    function actualizarTipo() {
        const t = tipoActual();
        const esVac = t?.dataset.vacaciones === '1';
        $('bloque-periodo').classList.toggle('d-none', !esVac);
        periodo.required = esVac;
        $('aviso-certificado').classList.toggle('d-none', t?.dataset.certificado !== '1');
        $('tipo-descripcion').textContent = t?.dataset.descripcion ?? '';
    }

    let temporizador;
    function calcular() {
        clearTimeout(temporizador);
        temporizador = setTimeout(async () => {
            if (!empleado.value || !tipo.value || !desde.value || !hasta.value) {
                $('calculo-vacio').classList.remove('d-none');
                $('calculo-datos').classList.add('d-none');
                return;
            }
            if (hasta.value < desde.value) hasta.value = desde.value;

            const params = new URLSearchParams({
                empleado_id: empleado.value, tipo_id: tipo.value, desde: desde.value, hasta: hasta.value,
                periodo: periodo.value || '', excluir: excluir || '',
            });
            try {
                const r = await fetch(urlCalculo + '?' + params, { headers: { 'Accept': 'application/json' } });
                if (!r.ok) return;
                const d = await r.json();

                $('calculo-vacio').classList.add('d-none');
                $('calculo-datos').classList.remove('d-none');
                $('calculo-dias').textContent = d.dias + (d.dias === 1 ? ' día' : ' días');
                $('calculo-unidad').textContent = d.unidad;

                const excede = d.maximo && d.dias > d.maximo;
                $('calculo-maximo').innerHTML = d.maximo
                    ? `<span class="${excede ? 'text-danger fw-semibold' : 'text-muted'}">Máximo del tipo: ${d.maximo} días</span>` : '';

                if (d.disponible !== undefined) {
                    const queda = d.disponible - d.dias;
                    $('calculo-saldo').innerHTML = `Saldo disponible: <strong>${d.disponible}</strong> días`
                        + `<br><span class="${queda < 0 ? 'text-danger fw-semibold' : 'text-success'}">Después de esta licencia: ${queda}</span>`;
                } else {
                    $('calculo-saldo').innerHTML = '';
                }

                $('calculo-avisos').innerHTML = (d.avisos || []).map(a => `<li>${a}</li>`).join('');
            } catch (e) { /* sin conexión: el servidor valida igual al guardar */ }
        }, 250);
    }

    tipo.addEventListener('change', () => { actualizarTipo(); calcular(); });
    [empleado, desde, hasta, periodo].forEach(el => el.addEventListener('change', calcular));
    actualizarTipo();
    calcular();
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/licencias/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Mi asistencia'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $Formato   = \App\Support\Formato::class;
    $anterior  = $desde->copy()->subMonth()->format('Y-m');
    $siguiente = $desde->copy()->addMonth()->format('Y-m');
?>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="input-group" style="width:auto">
        <a href="<?php echo e(route('portal.asistencia', ['mes' => $anterior])); ?>" class="btn btn-outline-secondary"><i class="bi bi-chevron-left"></i></a>
        <input type="month" name="mes" value="<?php echo e($mes); ?>" class="form-control" onchange="this.form.submit()">
        <a href="<?php echo e(route('portal.asistencia', ['mes' => $siguiente])); ?>" class="btn btn-outline-secondary"><i class="bi bi-chevron-right"></i></a>
    </form>
    <div class="small text-muted"><?php echo e($empleado->horario ? $empleado->horario->resumen : 'Sin horario asignado'); ?></div>
</div>

<div class="row g-2 mb-3">
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body py-2">
        <div class="small text-muted">Asistencias</div><div class="fs-5 fw-semibold"><?php echo e($totales['asistencias']); ?> / <?php echo e($totales['programados']); ?></div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body py-2">
        <div class="small text-muted">Ausencias</div><div class="fs-5 fw-semibold <?php echo e($totales['ausencias'] ? 'text-danger' : ''); ?>"><?php echo e($totales['ausencias']); ?></div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body py-2">
        <div class="small text-muted">Llegadas tarde</div><div class="fs-5 fw-semibold <?php echo e($totales['tardanzas'] ? 'text-warning' : ''); ?>"><?php echo e($totales['tardanzas']); ?></div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card border-0 shadow-sm h-100"><div class="card-body py-2">
        <div class="small text-muted">Horas extra</div><div class="fs-5 fw-semibold"><?php echo e($Formato::horas($totales['extra50'] + $totales['extra100'], '0:00')); ?></div>
    </div></div></div>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light">
                <tr><th>Día</th><th class="d-none d-sm-table-cell">Horario</th><th>Fichadas</th><th class="text-center">Trabajado</th><th class="text-center">Estado</th></tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($dia->estado === 'fuera') continue; ?>
                <tr class="<?php echo e($dia->fecha->isToday() ? 'table-primary' : ($dia->fecha->isWeekend() || $dia->feriado ? 'table-light' : '')); ?>">
                    <td class="text-nowrap">
                        <span class="fw-semibold"><?php echo e($dia->fecha->format('d')); ?></span>
                        <span class="small text-muted"><?php echo e(\App\Models\Horario::DIAS_CORTOS[$dia->fecha->dayOfWeekIso]); ?></span>
                    </td>
                    <td class="small d-none d-sm-table-cell"><?php echo e($dia->textoProgramado()); ?></td>
                    <td>
                        <?php $__currentLoopData = $dia->fichadas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge font-monospace <?php echo e($f->esEntrada() ? 'text-bg-success' : 'text-bg-danger'); ?>"><?php echo e($f->fecha_hora->format('H:i')); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="text-center small"><?php echo e($Formato::horas($dia->minutosTrabajados)); ?></td>
                    <td class="text-center">
                        <span class="badge text-bg-<?php echo e($dia->color()); ?>"><?php echo e($dia->etiqueta()); ?></span>
                        <?php if($dia->minutosTarde): ?><div class="small text-danger"><?php echo e($dia->minutosTarde); ?> min tarde</div><?php endif; ?>
                        <?php if($dia->licencia): ?><div class="small text-muted"><?php echo e($dia->licencia); ?></div><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<p class="small text-muted mt-2 mb-0">Si ves un error en tus fichadas (por ejemplo, te olvidaste de fichar la salida), avisale a RRHH para que lo corrija.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/asistencia.blade.php ENDPATH**/ ?>
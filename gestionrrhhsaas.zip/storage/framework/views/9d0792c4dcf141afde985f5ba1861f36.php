<?php $__env->startSection('title', 'Legajos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="d-flex flex-wrap gap-2">
        <input type="text" name="buscar" value="<?php echo e($buscar); ?>" class="form-control" style="max-width:240px"
               placeholder="Nombre, legajo, DNI o CUIL">
        <select name="area_id" class="form-select" style="max-width:220px">
            <option value="">Todas las áreas</option>
            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id); ?>" <?php if((string) $areaId === (string) $a->id): echo 'selected'; endif; ?>>
                    <?php echo e(str_repeat('— ', $a->nivel)); ?><?php echo e($a->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="estado" class="form-select" style="max-width:150px">
            <option value="activos" <?php if($estado === 'activos'): echo 'selected'; endif; ?>>Activos</option>
            <option value="bajas" <?php if($estado === 'bajas'): echo 'selected'; endif; ?>>Dados de baja</option>
            <option value="todos" <?php if($estado === 'todos'): echo 'selected'; endif; ?>>Todos</option>
        </select>
        <button class="btn btn-outline-secondary"><i class="bi bi-funnel"></i></button>
        <?php if($buscar || $areaId || $estado !== 'activos'): ?>
            <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-x-lg"></i></a>
        <?php endif; ?>
    </form>
    <a href="<?php echo e(route('empleados.create')); ?>" class="btn btn-primary">
        <i class="bi bi-person-plus me-1"></i>Nuevo legajo
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th style="width:80px">Legajo</th>
                    <th>Empleado</th>
                    <th class="d-none d-md-table-cell">CUIL</th>
                    <th class="d-none d-lg-table-cell">Área / Puesto</th>
                    <th class="d-none d-lg-table-cell">Categoría</th>
                    <th class="d-none d-md-table-cell">Ingreso</th>
                    <th class="text-center">Estado</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="cursor:pointer" onclick="window.location='<?php echo e(route('empleados.show', $emp)); ?>'">
                    <td class="text-muted"><?php echo e($emp->legajo); ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <?php if($emp->foto_url): ?>
                                <img src="<?php echo e($emp->foto_url); ?>" alt="" width="36" height="36" class="rounded-circle object-fit-cover">
                            <?php else: ?>
                                <span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary bg-opacity-10 text-primary fw-semibold small"
                                      style="width:36px;height:36px"><?php echo e($emp->iniciales); ?></span>
                            <?php endif; ?>
                            <div>
                                <a href="<?php echo e(route('empleados.show', $emp)); ?>" class="fw-semibold text-decoration-none text-dark"><?php echo e($emp->nombre_completo); ?></a>
                                <div class="small text-muted d-md-none"><?php echo e($emp->cuil); ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="d-none d-md-table-cell"><?php echo e($emp->cuil); ?></td>
                    <td class="d-none d-lg-table-cell">
                        <div><?php echo e($emp->area?->nombre ?? '—'); ?></div>
                        <div class="small text-muted"><?php echo e($emp->puesto?->nombre); ?></div>
                    </td>
                    <td class="d-none d-lg-table-cell"><?php echo e($emp->categoria?->nombre ?? 'Fuera de convenio'); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($emp->fecha_ingreso->format('d/m/Y')); ?></td>
                    <td class="text-center">
                        <?php if($emp->activo): ?>
                            <span class="badge text-bg-success">Activo</span>
                        <?php else: ?>
                            <span class="badge text-bg-secondary" title="<?php echo e($emp->motivo_egreso_nombre); ?>">Baja <?php echo e($emp->fecha_egreso->format('d/m/Y')); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay empleados para mostrar.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span class="small text-muted"><?php echo e($empleados->total()); ?> <?php echo e($empleados->total() === 1 ? 'empleado' : 'empleados'); ?></span>
    <?php echo e($empleados->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/empleados/index.blade.php ENDPATH**/ ?>
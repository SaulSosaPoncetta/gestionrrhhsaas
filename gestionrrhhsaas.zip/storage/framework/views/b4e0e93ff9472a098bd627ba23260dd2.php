<?php $__env->startSection('title', 'Mi portal'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $e = $empleado;
    $Formato = \App\Support\Formato::class;
    $hora = now()->hour;
    $saludo = $hora < 13 ? 'Buen día' : ($hora < 20 ? 'Buenas tardes' : 'Buenas noches');
?>

<h2 class="h5 mb-1"><?php echo e($saludo); ?>, <?php echo e($e->nombre); ?></h2>
<p class="text-muted small mb-4"><?php echo e(ucfirst(now()->locale('es')->isoFormat('dddd D [de] MMMM'))); ?> · <?php echo e($e->puesto?->nombre ?? 'Legajo ' . $e->legajo); ?></p>

<div class="row g-3">
    
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-semibold"><i class="bi bi-clock me-1"></i>Hoy</div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <div class="small text-muted">Tu horario</div>
                        <div class="fw-semibold"><?php echo e($hoy->textoProgramado()); ?></div>
                    </div>
                    <span class="badge text-bg-<?php echo e($hoy->color()); ?> fs-6"><?php echo e($hoy->etiqueta()); ?></span>
                </div>

                <?php if($hoy->licencia): ?>
                    <div class="alert alert-info py-2 small mb-3"><i class="bi bi-calendar-heart me-1"></i>Estás de licencia: <?php echo e($hoy->licencia); ?>.</div>
                <?php endif; ?>

                <div class="small text-muted mb-1">Fichadas de hoy</div>
                <div class="mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $hoy->fichadas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="badge font-monospace <?php echo e($f->esEntrada() ? 'text-bg-success' : 'text-bg-danger'); ?> me-1">
                            <?php echo e($f->esEntrada() ? 'Entrada' : 'Salida'); ?> <?php echo e($f->fecha_hora->format('H:i')); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-muted small">Todavía no fichaste.</span>
                    <?php endif; ?>
                </div>

                <?php if($e->permite_fichaje_web): ?>
                    <form method="POST" action="<?php echo e(route('portal.fichar')); ?>"
                          onsubmit="this.querySelector('button').disabled = true;">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-lg w-100 <?php echo e($proximo === 'entrada' ? 'btn-success' : 'btn-danger'); ?>">
                            <i class="bi <?php echo e($proximo === 'entrada' ? 'bi-box-arrow-in-right' : 'bi-box-arrow-right'); ?> me-1"></i>
                            Fichar <?php echo e($proximo); ?> · <?php echo e(now()->format('H:i')); ?>

                        </button>
                    </form>
                    <div class="form-text text-center">Se registra la hora del servidor y tu IP.</div>
                <?php else: ?>
                    <div class="small text-muted"><i class="bi bi-info-circle me-1"></i>Fichás con el reloj de la empresa.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="display-6 fw-semibold <?php echo e($saldo['saldo'] < 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e($saldo['saldo']); ?></div>
                <div>
                    <div class="fw-semibold">días de vacaciones <?php echo e($periodo); ?></div>
                    <div class="small text-muted">
                        Te corresponden <?php echo e($saldo['corresponden'] + $saldo['ajuste']); ?> · tomaste <?php echo e($saldo['tomados']); ?>

                        <?php if($saldo['pendientes']): ?> · <?php echo e($saldo['pendientes']); ?> pedidos sin aprobar <?php endif; ?>
                    </div>
                </div>
                <a href="<?php echo e(route('portal.licencias.create')); ?>" class="btn btn-outline-primary btn-sm ms-auto">Pedir</a>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span class="fw-semibold"><i class="bi bi-calendar-heart me-1"></i>Tus próximas licencias</span>
                <a href="<?php echo e(route('portal.licencias')); ?>" class="small">Ver todas</a>
            </div>
            <ul class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge text-bg-<?php echo e($l->tipo->color); ?>"><?php echo e($l->tipo->nombre); ?></span>
                            <div class="small text-muted"><?php echo e($l->periodo_texto); ?> · <?php echo e($l->dias); ?> días</div>
                        </div>
                        <span class="badge text-bg-<?php echo e($l->estado_color); ?>"><?php echo e($l->estado_nombre); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-muted small">No tenés licencias pedidas ni en curso.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    
    <?php if(auth()->user()->esSupervisor()): ?>
        <div class="col-12">
            <a href="<?php echo e(route('portal.equipo')); ?>" class="card border-0 shadow-sm text-decoration-none">
                <div class="card-body d-flex align-items-center gap-3">
                    <i class="bi bi-people fs-2 text-primary"></i>
                    <div>
                        <div class="fw-semibold text-dark">Mi equipo</div>
                        <div class="small text-muted">Asistencia de hoy y licencias de tu personal a cargo</div>
                    </div>
                    <?php if($pendientesEquipo): ?>
                        <span class="badge text-bg-warning ms-auto fs-6"><?php echo e($pendientesEquipo); ?> por aprobar</span>
                    <?php endif; ?>
                </div>
            </a>
        </div>
    <?php endif; ?>

    
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span class="fw-semibold"><i class="bi bi-receipt me-1"></i>Últimos recibos</span>
                <a href="<?php echo e(route('portal.recibos')); ?>" class="small">Ver todos</a>
            </div>
            <ul class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-semibold"><?php echo e($r->liquidacion->periodo_texto); ?></div>
                            <div class="small text-muted">Neto $ <?php echo e(number_format($r->neto, 2, ',', '.')); ?></div>
                        </div>
                        <div class="d-flex gap-2 align-items-center">
                            <?php if (! ($r->conformado_at)): ?><span class="badge text-bg-warning">Sin conformar</span><?php endif; ?>
                            <a href="<?php echo e(route('portal.recibos.ver', $r)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-muted small">Todavía no hay recibos disponibles.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/inicio.blade.php ENDPATH**/ ?>
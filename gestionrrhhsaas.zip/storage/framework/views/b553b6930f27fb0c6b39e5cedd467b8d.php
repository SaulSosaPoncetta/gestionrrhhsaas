<?php $__env->startSection('title', 'Mis datos'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $e = $empleado;
?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-header bg-white fw-semibold">Datos del legajo</div>
            <div class="card-body">
                <dl class="row mb-0 small">
                    <dt class="col-5 fw-normal text-muted">Legajo</dt><dd class="col-7"><?php echo e($e->legajo); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Apellido y nombre</dt><dd class="col-7"><?php echo e($e->nombre_completo); ?></dd>
                    <dt class="col-5 fw-normal text-muted">CUIL</dt><dd class="col-7"><?php echo e($e->cuil); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Ingreso</dt><dd class="col-7"><?php echo e($e->fecha_ingreso->format('d/m/Y')); ?> (<?php echo e($e->antiguedad); ?>)</dd>
                    <dt class="col-5 fw-normal text-muted">Área / puesto</dt><dd class="col-7"><?php echo e($e->area?->nombre ?? '—'); ?> · <?php echo e($e->puesto?->nombre ?? '—'); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Categoría</dt><dd class="col-7"><?php echo e($e->categoria?->nombre ?? 'Fuera de convenio'); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Horario</dt><dd class="col-7"><?php echo e($e->horario?->resumen ?? '—'); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Supervisor</dt><dd class="col-7"><?php echo e($e->supervisor?->nombre_completo ?? '—'); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Obra social</dt><dd class="col-7"><?php echo e($e->obra_social ?? '—'); ?></dd>
                    <dt class="col-5 fw-normal text-muted">Cuenta sueldo</dt><dd class="col-7"><?php echo e($e->banco ?? '—'); ?><?php echo e($e->cbu ? ' · CBU ' . substr($e->cbu, 0, 4) . '…' . substr($e->cbu, -4) : ''); ?></dd>
                </dl>
            </div>
            <div class="card-footer bg-white small text-muted">Para corregir alguno de estos datos, hablá con RRHH.</div>
        </div>

        <?php if($e->familiares->isNotEmpty()): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-semibold">Grupo familiar</div>
                <ul class="list-group list-group-flush small">
                    <?php $__currentLoopData = $e->familiares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between"><span><?php echo e($f->apellido_nombre); ?></span><span class="text-muted"><?php echo e($f->parentesco_nombre); ?></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>

    <div class="col-lg-7">
        <form method="POST" action="<?php echo e(route('portal.datos.update')); ?>" class="card border-0 shadow-sm">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="card-header bg-white fw-semibold">Contacto (lo podés actualizar vos)</div>
            <div class="card-body row g-3">
                <div class="col-md-8">
                    <label class="form-label">Domicilio</label>
                    <input type="text" name="domicilio" value="<?php echo e(old('domicilio', $e->domicilio)); ?>" class="form-control" maxlength="255">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Código postal</label>
                    <input type="text" name="codigo_postal" value="<?php echo e(old('codigo_postal', $e->codigo_postal)); ?>" class="form-control" maxlength="10">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Localidad</label>
                    <input type="text" name="localidad" value="<?php echo e(old('localidad', $e->localidad)); ?>" class="form-control" maxlength="255">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Provincia</label>
                    <input type="text" name="provincia" value="<?php echo e(old('provincia', $e->provincia)); ?>" class="form-control" maxlength="255">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Teléfono</label>
                    <input type="text" name="telefono" value="<?php echo e(old('telefono', $e->telefono)); ?>" class="form-control" maxlength="50">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email personal</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $e->email)); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="255">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Contacto de emergencia</label>
                    <input type="text" name="contacto_emergencia" value="<?php echo e(old('contacto_emergencia', $e->contacto_emergencia)); ?>" class="form-control" maxlength="255" placeholder="Nombre y vínculo">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Teléfono de emergencia</label>
                    <input type="text" name="telefono_emergencia" value="<?php echo e(old('telefono_emergencia', $e->telefono_emergencia)); ?>" class="form-control" maxlength="50">
                </div>
            </div>
            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                <a href="<?php echo e(route('password.editar')); ?>" class="small"><i class="bi bi-key me-1"></i>Cambiar contraseña</a>
                <button class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/portal/datos.blade.php ENDPATH**/ ?>
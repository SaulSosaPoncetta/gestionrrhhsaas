<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="h5 mb-4">Hola, <?php echo e($user->name); ?></h2>

<?php if($user->esSuperadmin()): ?>
    <div class="row g-3">
        <div class="col-sm-6 col-lg-4">
            <div class="card border-0 shadow-sm"><div class="card-body">
                <div class="text-muted small">Empresas</div>
                <div class="fs-3 fw-semibold"><?php echo e($stats['empresas']); ?></div>
                <div class="small text-success"><?php echo e($stats['activas']); ?> activas</div>
            </div></div>
        </div>
        <div class="col-sm-6 col-lg-4">
            <div class="card border-0 shadow-sm"><div class="card-body">
                <div class="text-muted small">Usuarios</div>
                <div class="fs-3 fw-semibold"><?php echo e($stats['usuarios']); ?></div>
            </div></div>
        </div>
    </div>
<?php else: ?>
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <a href="<?php echo e(route('empleados.index')); ?>" class="card border-0 shadow-sm text-decoration-none h-100"><div class="card-body">
                <div class="text-muted small">Empleados activos</div>
                <div class="fs-3 fw-semibold text-dark"><?php echo e($stats['activos']); ?></div>
            </div></a>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Ingresos del mes</div>
                <div class="fs-3 fw-semibold text-success"><?php echo e($stats['ingresos']); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Egresos del mes</div>
                <div class="fs-3 fw-semibold text-danger"><?php echo e($stats['egresos']); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100"><div class="card-body">
                <div class="text-muted small">Usuarios del sistema</div>
                <div class="fs-3 fw-semibold text-dark"><?php echo e($stats['usuarios']); ?></div>
            </div></div>
        </div>
    </div>

    
    <?php
        $presentesHoy = ($asistenciaHoy['presente'] ?? 0) + ($asistenciaHoy['trabajando'] ?? 0) + ($asistenciaHoy['tarde'] ?? 0);
        $resumenHoy = [
            ['Presentes', $presentesHoy, 'success', null],
            ['Llegadas tarde', $asistenciaHoy['tarde'] ?? 0, 'warning', 'tarde'],
            ['Ausentes', $asistenciaHoy['ausente'] ?? 0, 'danger', 'ausente'],
            ['De licencia', $asistenciaHoy['licencia'] ?? 0, 'info', 'licencia'],
            ['Pendientes', $asistenciaHoy['pendiente'] ?? 0, 'secondary', 'pendiente'],
        ];
    ?>
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span class="fw-semibold"><i class="bi bi-clipboard-check text-primary me-1"></i>Asistencia de hoy</span>
            <a href="<?php echo e(route('asistencia.parte')); ?>" class="small">Ver parte diario</a>
        </div>
        <div class="card-body row text-center g-2">
            <?php $__currentLoopData = $resumenHoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$titulo, $valor, $color, $filtro]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <a href="<?php echo e(route('asistencia.parte', array_filter(['estado' => $filtro]))); ?>" class="text-decoration-none">
                        <div class="fs-3 fw-semibold text-<?php echo e($color === 'secondary' ? 'dark' : $color); ?>"><?php echo e($valor); ?></div>
                        <div class="small text-muted"><?php echo e($titulo); ?></div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <a href="<?php echo e(route('licencias.index', ['estado' => 'pendiente'])); ?>" class="card border-0 shadow-sm text-decoration-none h-100">
                <div class="card-body">
                    <div class="text-muted small">Licencias pendientes de aprobar</div>
                    <div class="fs-3 fw-semibold <?php echo e($licenciasPendientes ? 'text-warning' : 'text-dark'); ?>"><?php echo e($licenciasPendientes); ?></div>
                </div>
            </a>
        </div>
        <div class="col-md-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <span class="fw-semibold"><i class="bi bi-calendar-heart text-info me-1"></i>De licencia hoy</span>
                    <a href="<?php echo e(route('licencias.calendario')); ?>" class="small">Calendario</a>
                </div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $deLicenciaHoy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(route('empleados.show', $lic->empleado)); ?>#licencias" class="text-decoration-none"><?php echo e($lic->empleado->nombre_completo); ?></a>
                            <span class="small">
                                <span class="badge text-bg-<?php echo e($lic->tipo->color); ?>"><?php echo e($lic->tipo->nombre); ?></span>
                                <span class="text-muted">hasta el <?php echo e($lic->fecha_hasta->format('d/m')); ?></span>
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted small">Nadie está de licencia hoy.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white fw-semibold">
                    <i class="bi bi-exclamation-triangle text-warning me-1"></i>Documentos vencidos o por vencer
                </div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $documentosAlerta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <a href="<?php echo e(route('empleados.show', $doc->empleado)); ?>#documentos" class="fw-semibold text-decoration-none">
                                    <?php echo e($doc->empleado->nombre_completo); ?>

                                </a>
                                <div class="small text-muted"><?php echo e($doc->tipo_nombre); ?></div>
                            </div>
                            <span class="badge <?php echo e($doc->estado_vencimiento === 'vencido' ? 'text-bg-danger' : 'text-bg-warning'); ?>">
                                <?php echo e($doc->vencimiento->format('d/m/Y')); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted small">No hay documentos con vencimiento en los próximos 30 días.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-header bg-white fw-semibold"><i class="bi bi-cake2 text-primary me-1"></i>Cumpleaños del mes</div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $cumpleanios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between">
                            <a href="<?php echo e(route('empleados.show', $emp)); ?>" class="text-decoration-none"><?php echo e($emp->nombre_completo); ?></a>
                            <span class="small <?php echo e($emp->fecha_nacimiento->day === now()->day ? 'fw-semibold text-primary' : 'text-muted'); ?>">
                                <?php echo e($emp->fecha_nacimiento->format('d/m')); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted small">Nadie cumple años este mes.</li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-semibold"><i class="bi bi-award text-success me-1"></i>Aniversarios laborales del mes</div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $aniversarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between">
                            <a href="<?php echo e(route('empleados.show', $emp)); ?>" class="text-decoration-none"><?php echo e($emp->nombre_completo); ?></a>
                            <span class="small text-muted">
                                <?php echo e(now()->year - $emp->fecha_ingreso->year); ?> <?php echo e(now()->year - $emp->fecha_ingreso->year === 1 ? 'año' : 'años'); ?>

                                · <?php echo e($emp->fecha_ingreso->format('d/m')); ?>

                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-muted small">No hay aniversarios este mes.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/dashboard.blade.php ENDPATH**/ ?>
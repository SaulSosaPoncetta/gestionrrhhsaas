<?php $__env->startSection('title', 'Calendario de licencias'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .cal th, .cal td { padding: .25rem .15rem; font-size: .75rem; text-align: center; min-width: 24px; }
    .cal td.nombre, .cal th.nombre { text-align: left; min-width: 180px; position: sticky; left: 0; background: #fff; z-index: 1; }
    .cal .finde { background: #f1f3f5; }
    .cal .feriado { background: #fde2e1; }
    .cal .hoy { outline: 2px solid var(--bs-primary); outline-offset: -2px; }
    .cal .celda { display: block; height: 22px; border-radius: 3px; }
    .cal .celda.pendiente { opacity: .45; background-image: repeating-linear-gradient(45deg, transparent 0 4px, rgba(255,255,255,.6) 4px 8px); }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $anterior  = $desde->copy()->subMonth()->format('Y-m');
    $siguiente = $desde->copy()->addMonth()->format('Y-m');
?>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
    <form method="GET" class="input-group" style="width:auto">
        <a href="<?php echo e(route('licencias.calendario', ['mes' => $anterior])); ?>" class="btn btn-outline-secondary"><i class="bi bi-chevron-left"></i></a>
        <input type="month" name="mes" value="<?php echo e($mes); ?>" class="form-control" onchange="this.form.submit()">
        <a href="<?php echo e(route('licencias.calendario', ['mes' => $siguiente])); ?>" class="btn btn-outline-secondary"><i class="bi bi-chevron-right"></i></a>
    </form>
    <a href="<?php echo e(route('licencias.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nueva licencia</a>
</div>

<h2 class="h6 text-muted mb-3"><?php echo e(ucfirst($desde->locale('es')->isoFormat('MMMM [de] YYYY'))); ?></h2>

<?php if($filas->isEmpty()): ?>
    <div class="card border-0 shadow-sm"><div class="card-body text-center text-muted py-5">
        No hay licencias aprobadas ni pendientes en este mes.
    </div></div>
<?php else: ?>
    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-bordered cal mb-0">
                <thead>
                    <tr>
                        <th class="nombre">Empleado</th>
                        <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="<?php echo e($d->isWeekend() ? 'finde' : ''); ?> <?php echo e(isset($feriados[$d->toDateString()]) ? 'feriado' : ''); ?> <?php echo e($d->isToday() ? 'hoy' : ''); ?>"
                                title="<?php echo e($feriados[$d->toDateString()] ?? ''); ?>">
                                <div class="text-muted"><?php echo e(mb_substr(\App\Models\Horario::DIAS_CORTOS[$d->dayOfWeekIso], 0, 1)); ?></div>
                                <?php echo e($d->day); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th title="Días de licencia aprobada en el mes">Días</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $filas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="nombre">
                            <a href="<?php echo e(route('empleados.show', $fila['empleado'])); ?>#licencias" class="text-decoration-none"><?php echo e($fila['empleado']->nombre_completo); ?></a>
                        </td>
                        <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $lic = $fila['celdas'][$d->toDateString()];
                            ?>
                            <td class="<?php echo e($d->isWeekend() ? 'finde' : ''); ?> <?php echo e(isset($feriados[$d->toDateString()]) ? 'feriado' : ''); ?>">
                                <?php if($lic): ?>
                                    <a href="<?php echo e(route('licencias.edit', $lic)); ?>"
                                       class="celda bg-<?php echo e($lic->tipo->color); ?> <?php echo e($lic->esPendiente() ? 'pendiente' : ''); ?>"
                                       title="<?php echo e($lic->tipo->nombre); ?> · <?php echo e($lic->periodo_texto); ?> · <?php echo e($lic->estado_nombre); ?>"></a>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="fw-semibold"><?php echo e($fila['dias']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="d-flex flex-wrap gap-3 mt-2 small">
        <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span><span class="badge text-bg-<?php echo e($t->color); ?>">&nbsp;</span> <?php echo e($t->nombre); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <span><span class="badge text-bg-secondary opacity-50">&nbsp;</span> Pendiente de aprobación (rayado)</span>
        <span><span class="badge" style="background:#fde2e1">&nbsp;</span> Feriado</span>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/licencias/calendario.blade.php ENDPATH**/ ?>
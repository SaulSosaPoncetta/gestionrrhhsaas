
<div class="modal fade" id="modalFichada" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('fichadas.store')); ?>" id="formFichada" class="modal-content">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" id="fichadaMetodo" value="POST">
            <input type="hidden" name="_origen" value="fichada">
            <input type="hidden" name="_fichada_id" id="fichadaId" value="">
            <div class="modal-header">
                <h5 class="modal-title" id="fichadaTitulo">Registrar fichada</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body row g-3">
                <div class="col-12">
                    <label class="form-label">Empleado *</label>
                    <select name="empleado_id" class="form-select" required>
                        <option value="">— Seleccionar —</option>
                        <?php $__currentLoopData = $empleadosFichada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ef->id); ?>"><?php echo e($ef->apellido); ?>, <?php echo e($ef->nombre); ?> (leg. <?php echo e($ef->legajo); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-6">
                    <label class="form-label">Fecha *</label>
                    <input type="date" name="fecha" class="form-control" max="<?php echo e(now()->format('Y-m-d')); ?>" required>
                </div>
                <div class="col-6">
                    <label class="form-label">Hora *</label>
                    <input type="time" name="hora" class="form-control" required>
                </div>
                <div class="col-12">
                    <label class="form-label d-block">Tipo *</label>
                    <div class="btn-group w-100" role="group">
                        <input type="radio" class="btn-check" name="tipo" value="entrada" id="tipoEntrada" required>
                        <label class="btn btn-outline-success" for="tipoEntrada"><i class="bi bi-box-arrow-in-right me-1"></i>Entrada</label>
                        <input type="radio" class="btn-check" name="tipo" value="salida" id="tipoSalida">
                        <label class="btn btn-outline-danger" for="tipoSalida"><i class="bi bi-box-arrow-right me-1"></i>Salida</label>
                    </div>
                </div>
                <div class="col-12">
                    <label class="form-label">Observación</label>
                    <input type="text" name="observacion" class="form-control" maxlength="255" placeholder="Ej: se olvidó de fichar, falla del reloj...">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-danger me-auto d-none" id="fichadaEliminar">
                    <i class="bi bi-trash me-1"></i>Eliminar
                </button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-primary"><i class="bi bi-check-lg me-1"></i>Guardar</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="formEliminarFichada" class="d-none">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form>

<?php $__env->startPush('scripts'); ?>
<script>
const urlAltaFichada = <?php echo json_encode(route('fichadas.store'), 15, 512) ?>;
const urlEditarFichada = <?php echo json_encode(route('fichadas.update', '__ID__'), 512) ?>;

function abrirFichada(datos = {}) {
    const form = document.getElementById('formFichada');
    const editar = !!datos.id;

    form.reset();
    form.action = editar ? urlEditarFichada.replace('__ID__', datos.id) : urlAltaFichada;
    document.getElementById('fichadaMetodo').value = editar ? 'PUT' : 'POST';
    document.getElementById('fichadaId').value = datos.id ?? '';
    document.getElementById('fichadaTitulo').textContent = editar ? 'Editar fichada' : 'Registrar fichada';

    form.empleado_id.value = datos.empleado_id ?? '';
    form.fecha.value = datos.fecha ?? <?php echo json_encode(now()->format('Y-m-d'), 15, 512) ?>;
    form.hora.value = datos.hora ?? '';
    form.observacion.value = datos.observacion ?? '';
    if (datos.tipo) {
        form.querySelector(`input[name=tipo][value=${datos.tipo}]`).checked = true;
    }

    const eliminar = document.getElementById('fichadaEliminar');
    eliminar.classList.toggle('d-none', !editar);
    eliminar.onclick = () => {
        if (!confirm('¿Eliminar esta fichada?')) return;
        const f = document.getElementById('formEliminarFichada');
        f.action = urlEditarFichada.replace('__ID__', datos.id);
        f.submit();
    };

    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalFichada')).show();
}

<?php if($errors->any() && old('_origen') === 'fichada'): ?>
    // Si la validación falló, se vuelve a abrir el modal con lo que se había cargado
    document.addEventListener('DOMContentLoaded', () => abrirFichada({
        id: <?php echo json_encode(old('_fichada_id'), 15, 512) ?> || null,
        empleado_id: <?php echo json_encode(old('empleado_id'), 15, 512) ?>,
        fecha: <?php echo json_encode(old('fecha'), 15, 512) ?>,
        hora: <?php echo json_encode(old('hora'), 15, 512) ?>,
        tipo: <?php echo json_encode(old('tipo'), 15, 512) ?>,
        observacion: <?php echo json_encode(old('observacion'), 15, 512) ?>,
    }));
<?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/asistencia/_modal_fichada.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Tipos de licencia'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <form method="POST" action="<?php echo e(route('tipos-licencia.predeterminados')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-outline-primary"><i class="bi bi-magic me-1"></i>Cargar los tipos de la LCT</button>
    </form>
    <a href="<?php echo e(route('tipos-licencia.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Nuevo tipo</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Tipo</th>
                    <th class="text-center">Días</th>
                    <th class="text-center d-none d-md-table-cell">Máximo</th>
                    <th class="text-center d-none d-md-table-cell">Con goce</th>
                    <th class="text-center d-none d-md-table-cell">Certificado</th>
                    <th class="text-center d-none d-lg-table-cell">Licencias</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <span class="badge text-bg-<?php echo e($t->color); ?> me-1"><?php echo e($t->codigo ?: '·'); ?></span>
                        <span class="fw-semibold"><?php echo e($t->nombre); ?></span>
                        <?php if($t->es_vacaciones): ?><span class="badge text-bg-light">vacaciones</span><?php endif; ?>
                        <?php if($t->descripcion): ?><div class="small text-muted"><?php echo e($t->descripcion); ?></div><?php endif; ?>
                    </td>
                    <td class="text-center small"><?php echo e($t->esHabiles() ? 'Hábiles' : 'Corridos'); ?></td>
                    <td class="text-center d-none d-md-table-cell small">
                        <?php if($t->es_vacaciones): ?>
                            Según antigüedad
                        <?php else: ?>
                            <?php echo e($t->dias_maximos ? $t->dias_maximos . ' por licencia' : '—'); ?>

                            <?php if($t->maximo_anual): ?><div class="text-muted"><?php echo e($t->maximo_anual); ?> por año</div><?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td class="text-center d-none d-md-table-cell"><?php echo $t->con_goce ? '<i class="bi bi-check-lg text-success"></i>' : '<span class="text-danger small">Sin goce</span>'; ?></td>
                    <td class="text-center d-none d-md-table-cell"><?php echo $t->requiere_certificado ? '<i class="bi bi-file-earmark-medical text-primary"></i>' : '—'; ?></td>
                    <td class="text-center d-none d-lg-table-cell"><?php echo e($t->licencias_count); ?></td>
                    <td class="text-center">
                        <span class="badge <?php echo e($t->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>"><?php echo e($t->activo ? 'Activo' : 'Inactivo'); ?></span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('tipos-licencia.edit', $t)); ?>" class="btn btn-sm btn-outline-primary" title="Editar"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="<?php echo e(route('tipos-licencia.destroy', $t)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar el tipo <?php echo e(addslashes($t->nombre)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">
                    No hay tipos de licencia. Usá «Cargar los tipos de la LCT» para empezar con los de la ley.
                </td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="small text-muted mt-2 mb-0">Si el convenio colectivo da más días que la ley, editá el tipo y cambiá el máximo.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/tipos_licencia/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Convenios colectivos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end mb-3">
    <a href="<?php echo e(route('convenios.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nuevo convenio
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Convenio</th>
                    <th>N° CCT</th>
                    <th class="d-none d-md-table-cell">Sindicato</th>
                    <th class="d-none d-md-table-cell text-center">Hs. semanales</th>
                    <th class="text-center">Categorías</th>
                    <th class="text-center">Estado</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $convenios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convenio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($convenio->nombre); ?></td>
                    <td><?php echo e($convenio->numero ?? '—'); ?></td>
                    <td class="d-none d-md-table-cell"><?php echo e($convenio->sindicato ?? '—'); ?></td>
                    <td class="d-none d-md-table-cell text-center">
                        <?php echo e($convenio->horas_semanales ? rtrim(rtrim(number_format($convenio->horas_semanales, 2, ',', '.'), '0'), ',') : '—'); ?>

                    </td>
                    <td class="text-center">
                        <a href="<?php echo e(route('convenios.categorias.index', $convenio)); ?>" class="btn btn-sm btn-outline-secondary">
                            <?php echo e($convenio->categorias_count); ?> <i class="bi bi-chevron-right small"></i>
                        </a>
                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo e($convenio->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                            <?php echo e($convenio->activo ? 'Activo' : 'Inactivo'); ?>

                        </span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('convenios.edit', $convenio)); ?>" class="btn btn-sm btn-outline-primary" title="Editar">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('convenios.destroy', $convenio)); ?>" class="d-inline"
                              onsubmit="return confirm('¿Eliminar el convenio <?php echo e(addslashes($convenio->nombre)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger" title="Eliminar"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No hay convenios cargados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\shsp1975\Documents\DESARROLLOS\gestionrrhh\resources\views/convenios/index.blade.php ENDPATH**/ ?>